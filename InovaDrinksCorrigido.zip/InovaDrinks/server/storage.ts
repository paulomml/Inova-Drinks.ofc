import { type User, type InsertUser, type Package, type InsertPackage, type Booking, type InsertBooking } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllPackages(): Promise<Package[]>;
  getPackage(id: string): Promise<Package | undefined>;
  createPackage(pkg: InsertPackage): Promise<Package>;
  
  getAllBookings(): Promise<Booking[]>;
  getBooking(id: string): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: string, status: string): Promise<Booking | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private packages: Map<string, Package>;
  private bookings: Map<string, Booking>;

  constructor() {
    this.users = new Map();
    this.packages = new Map();
    this.bookings = new Map();
    
    // Initialize with default packages
    this.initializePackages();
  }

  private initializePackages() {
    const defaultPackages: InsertPackage[] = [
      {
        name: "Pacote Clássico",
        type: "classico",
        pricePerPerson: "35.00",
        description: "Perfeito para eventos casuais com bebidas tradicionais e frutas frescas.",
        drinks: [
          "Caipirinha tradicional",
          "Caipirosca (morango/limão)",
          "Caipifrutas variadas",
          "Mix da estação"
        ],
        cocktails: [
          "Tropical (com/sem álcool)",
          "Sublime (com/sem álcool)",
          "Grape (com/sem álcool)"
        ],
        features: [
          "Open bar ilimitado",
          "Frutas frescas",
          "Atendimento básico"
        ],
        isPopular: "false"
      },
      {
        name: "Pacote VIP",
        type: "vip",
        pricePerPerson: "50.00",
        description: "Experiência premium com drinks exclusivos e serviço personalizado.",
        drinks: [
          "Todo o pacote Clássico",
          "Ruby Red premium",
          "Doçura de Kiwi especial"
        ],
        cocktails: [
          "Blue Lagoon",
          "Sex on the Beach",
          "Tropical & Sublime premium"
        ],
        features: [
          "Tudo do pacote Clássico",
          "Drinks exclusivos",
          "Serviço personalizado"
        ],
        isPopular: "true"
      },
      {
        name: "Pacote Premium",
        type: "premium",
        pricePerPerson: "75.00",
        description: "Experiência de luxo com champagnes, drinks exclusivos e serviço completo.",
        drinks: [
          "Todo o pacote VIP",
          "Mojito artesanal",
          "Champagnes selecionados"
        ],
        cocktails: [
          "Frutas especiais da estação",
          "Estrutura completa incluída",
          "Taças de cristal"
        ],
        features: [
          "Tudo do pacote VIP",
          "Champagnes premium",
          "Estrutura completa",
          "Taças de cristal"
        ],
        isPopular: "false"
      }
    ];

    defaultPackages.forEach(pkg => {
      this.createPackage(pkg);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllPackages(): Promise<Package[]> {
    return Array.from(this.packages.values());
  }

  async getPackage(id: string): Promise<Package | undefined> {
    return this.packages.get(id);
  }

  async createPackage(insertPackage: InsertPackage): Promise<Package> {
    const id = randomUUID();
    const pkg: Package = { ...insertPackage, id, isPopular: insertPackage.isPopular ?? null };
    this.packages.set(id, pkg);
    return pkg;
  }

  async getAllBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBooking(id: string): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = { 
      ...insertBooking, 
      id,
      status: "pending",
      createdAt: new Date()
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async updateBookingStatus(id: string, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) {
      return undefined;
    }
    
    const updatedBooking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }
}

export const storage = new MemStorage();
