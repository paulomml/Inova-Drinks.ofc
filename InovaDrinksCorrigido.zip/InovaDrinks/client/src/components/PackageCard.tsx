import { Martini, GlassWater, Crown } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { DisplayPackage } from "../pages/home";

interface PackageCardProps {
  package: DisplayPackage;
  isSelected: boolean;
  onSelect: (packageId: string) => void;
}

export default function PackageCard({ package: pkg, isSelected, onSelect }: PackageCardProps) {
  const handleSelect = () => {
    onSelect(pkg.id);
    // Scroll to booking summary
    setTimeout(() => {
      document.querySelector('.bg-gradient-to-br.from-primary\\/5')?.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }, 300);
  };

  return (
    <Card className={`overflow-hidden shadow-soft hover:shadow-strong transition-all duration-300 hover:-translate-y-2 relative ${
      isSelected ? 'border-primary border-2 shadow-strong' : 'border-border border-2'
    } ${pkg.isPopular ? 'border-primary border-2 shadow-strong' : ''}`}>
      {pkg.isPopular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-accent to-accent-light text-white px-4 py-1 rounded-full text-sm font-medium z-10">
          Mais Popular
        </div>
      )}
      
      <div className="relative">
        <img 
          src={pkg.image} 
          alt={pkg.name} 
          className="w-full h-48 sm:h-56 object-cover" 
        />
        <div className={`absolute top-4 left-4 ${pkg.badgeColor} text-white px-3 py-1 rounded-full text-sm font-medium`}>
          {pkg.badge}
        </div>
      </div>
      
      <CardContent className="p-4 sm:p-6">
        <h3 className="font-poppins font-semibold text-lg sm:text-xl text-text-primary mb-3">
          {pkg.name}
        </h3>
        <p className="text-text-secondary mb-4 text-sm sm:text-base">
          {pkg.description}
        </p>
        
        <div className="space-y-4 mb-6">
          <div>
            <h4 className="font-medium text-text-primary mb-2 flex items-center">
              <Martini className="text-primary mr-2 h-4 w-4" />
              Drinks Inclusos
            </h4>
            <ul className="text-sm text-text-secondary space-y-1">
              {Array.isArray(pkg.drinks) && pkg.drinks.map((drink: string, index: number) => (
                <li key={index}>• {drink}</li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-text-primary mb-2 flex items-center">
              {pkg.type === 'premium' ? (
                <Crown className="text-yellow-500 mr-2 h-4 w-4" />
              ) : (
                <GlassWater className="text-secondary mr-2 h-4 w-4" />
              )}
              {pkg.type === 'premium' ? 'Extras Premium' : 'Coquetéis'}
            </h4>
            <ul className="text-sm text-text-secondary space-y-1">
              {Array.isArray(pkg.cocktails) && pkg.cocktails.map((cocktail: string, index: number) => (
                <li key={index}>• {cocktail}</li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <div className="flex justify-between items-center mb-4">
            <span className="text-text-secondary">Preço por pessoa:</span>
            <span className="font-bold text-xl text-primary">
              R$ {pkg.pricePerPerson.toFixed(2)}
            </span>
          </div>
          <Button 
            onClick={handleSelect}
            className={`w-full font-semibold py-3 text-white transition-all ${pkg.buttonColor}`}
          >
            Selecionar Pacote
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
