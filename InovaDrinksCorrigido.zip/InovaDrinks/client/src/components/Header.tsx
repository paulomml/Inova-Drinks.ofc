import { Menu, User } from "lucide-react";
import { Button } from "./ui/button";
// Using public path for asset

export default function Header() {
  return (
    <header className="bg-card shadow-soft sticky top-0 z-50 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <img 
              src="/assets/logo_1754710169373.png" 
              alt="Inova Drinks Logo" 
              className="w-16 h-16 sm:w-20 sm:h-20 object-contain"
            />
            <div>
              <h1 className="font-poppins font-bold text-xl sm:text-2xl text-text-primary">Inova Drinks</h1>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-text-secondary hover:text-primary transition-colors font-medium">
              Início
            </a>
            <a href="#packages" className="text-text-secondary hover:text-primary transition-colors font-medium">
              Pacotes
            </a>
            <a href="#" className="text-text-secondary hover:text-primary transition-colors font-medium">
              Sobre
            </a>
            <a href="#" className="text-text-secondary hover:text-primary transition-colors font-medium">
              Contato
            </a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="hidden sm:flex text-text-secondary hover:text-primary">
              <User className="mr-2 h-4 w-4" />
              Entrar
            </Button>
            <Button variant="ghost" className="md:hidden text-text-secondary">
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
