import { Martini, Phone, Mail, MapPin } from "lucide-react";
import { FaInstagram, FaFacebook, FaWhatsapp } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-muted text-foreground py-12 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary-dark rounded-lg flex items-center justify-center">
                <Martini className="text-primary-foreground h-5 w-5" />
              </div>
              <span className="font-poppins font-bold text-xl">Inova Drinks</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Transformando eventos em experiências memoráveis através de bebidas artesanais e atendimento excepcional.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contato</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="flex items-center">
                <Phone className="mr-2 h-4 w-4" />
                (11) 99999-9999
              </p>
              <p className="flex items-center">
                <Mail className="mr-2 h-4 w-4" />
                contato@inovadrinks.com
              </p>
              <p className="flex items-center">
                <MapPin className="mr-2 h-4 w-4" />
                São Paulo, SP
              </p>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Serviços</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Open Bar para Eventos</p>
              <p>Coquetéis Personalizados</p>
              <p>Bartenders Profissionais</p>
              <p>Estrutura Completa</p>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Redes Sociais</h4>
            <div className="flex space-x-4">
              <a href="#" className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center hover:bg-primary-light transition-colors">
                <FaInstagram className="text-sm" />
              </a>
              <a href="#" className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center hover:bg-primary-light transition-colors">
                <FaFacebook className="text-sm" />
              </a>
              <a href="#" className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center hover:bg-primary-light transition-colors">
                <FaWhatsapp className="text-sm" />
              </a>
            </div>
          </div>
        </div>
        
        <hr className="border-border my-8" />
        
        <div className="text-center text-sm text-muted-foreground">
          <p>&copy; 2024 Inova Drinks. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
