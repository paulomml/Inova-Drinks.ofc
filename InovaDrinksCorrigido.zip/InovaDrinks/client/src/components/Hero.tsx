import { CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

interface HeroProps {
  guestCount: number;
  setGuestCount: (count: number) => void;
  onScrollToPackages: () => void;
  totalPrice: number;
}

const GUEST_OPTIONS = [50, 100, 150, 200];

export default function Hero({ guestCount, setGuestCount, onScrollToPackages, totalPrice }: HeroProps) {
  const pricePerPerson = 45; // Base price for estimation

  return (
    <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="font-poppins font-bold text-4xl lg:text-5xl text-text-primary mb-6 leading-tight">
              Experiência <span className="text-primary">Premium</span> em Bebidas para Eventos
            </h2>
            <p className="text-lg text-text-secondary mb-8 leading-relaxed">
              Transforme seu evento com nosso serviço de open bar exclusivo. Drinks artesanais, 
              frutas frescas e atendimento profissional para tornar sua celebração inesquecível.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              <div className="flex items-center text-text-secondary">
                <CheckCircle className="text-success mr-2 h-5 w-5" />
                <span>Open Bar Ilimitado</span>
              </div>
              <div className="flex items-center text-text-secondary">
                <CheckCircle className="text-success mr-2 h-5 w-5" />
                <span>Frutas Frescas</span>
              </div>
              <div className="flex items-center text-text-secondary">
                <CheckCircle className="text-success mr-2 h-5 w-5" />
                <span>Opções Sem Álcool</span>
              </div>
            </div>
          </div>
          
          <Card className="shadow-medium">
            <CardContent className="p-8">
              <h3 className="font-poppins font-semibold text-2xl text-text-primary mb-6">
                Calcule seu Orçamento
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-text-primary mb-3">
                    Número de Convidados
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {GUEST_OPTIONS.map((count) => (
                      <Button
                        key={count}
                        variant={guestCount === count ? "default" : "outline"}
                        className={`p-4 font-medium transition-all text-sm sm:text-base ${
                          guestCount === count 
                            ? "border-primary bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg" 
                            : "border-border text-text-secondary hover:border-primary hover:text-primary hover:bg-primary/5"
                        }`}
                        onClick={() => setGuestCount(count)}
                      >
                        {count === 200 ? "200+ pessoas" : `${count} pessoas`}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-xl p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-text-secondary">Estimativa por pessoa:</span>
                    <span className="font-semibold text-primary">
                      R$ {pricePerPerson.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-text-primary">Total estimado:</span>
                    <span className="font-bold text-2xl text-primary">
                      R$ {(guestCount * pricePerPerson).toFixed(2)}
                    </span>
                  </div>
                </div>
                
                <Button 
                  onClick={onScrollToPackages}
                  className="w-full bg-gradient-to-r from-primary to-primary-light text-white font-semibold py-4 hover:shadow-medium transition-all duration-300 transform hover:-translate-y-1"
                >
                  Ver Pacotes Disponíveis
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
