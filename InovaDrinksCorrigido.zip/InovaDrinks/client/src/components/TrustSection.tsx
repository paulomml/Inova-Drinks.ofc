import { Award, Leaf, Headphones } from "lucide-react";
// Using public path for asset

export default function TrustSection() {
  const features = [
    {
      icon: Award,
      title: "Experiência Comprovada",
      description: "Mais de 500 eventos realizados com excelência e satisfação garantida.",
      color: "bg-primary"
    },
    {
      icon: Leaf,
      title: "Ingredientes Frescos", 
      description: "Utilizamos apenas frutas da estação e ingredientes premium selecionados.",
      color: "bg-secondary"
    },
    {
      icon: Headphones,
      title: "Suporte Completo",
      description: "Atendimento personalizado desde o planejamento até a execução do evento.",
      color: "bg-accent"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-poppins font-bold text-3xl text-text-primary mb-4">
            Por que Escolher a Inova Drinks?
          </h2>
          <p className="text-lg text-text-secondary mb-8">
            Nossa equipe profissional garante a excelência em cada evento
          </p>
          <div className="max-w-4xl mx-auto mb-12">
            <img 
              src="/assets/team_1754710169375.jpg" 
              alt="Equipe profissional Inova Drinks" 
              className="w-full h-80 object-cover rounded-2xl shadow-medium"
            />
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className={`w-16 h-16 ${feature.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <feature.icon className="text-white h-8 w-8" />
              </div>
              <h3 className="font-poppins font-semibold text-lg text-text-primary mb-2">
                {feature.title}
              </h3>
              <p className="text-text-secondary">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
