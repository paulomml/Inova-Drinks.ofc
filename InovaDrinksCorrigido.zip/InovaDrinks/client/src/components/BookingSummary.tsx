import { ClipboardList, User, CalendarCheck } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "../../../shared/schema";
import { useToast } from "../hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "../lib/queryClient";
import { z } from "zod";

type BookingFormData = z.infer<typeof insertBookingSchema>;

interface BookingSummaryProps {
  guestCount: number;
  selectedPackage: any;
  totalPrice: number;
}

export default function BookingSummary({ guestCount, selectedPackage, totalPrice }: BookingSummaryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm<BookingFormData>({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      guestCount,
      packageId: selectedPackage?.id || '',
      totalPrice: totalPrice.toString(),
    }
  });

  const bookingMutation = useMutation({
    mutationFn: (data: BookingFormData) => apiRequest('POST', '/api/bookings', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      toast({
        title: "Orçamento Solicitado!",
        description: "Entraremos em contato em até 24 horas para confirmar os detalhes.",
      });
      reset();
    },
    onError: (error) => {
      console.error('Booking error:', error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao enviar sua solicitação. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: BookingFormData) => {
    if (!selectedPackage) {
      toast({
        title: "Erro",
        description: "Por favor, selecione um pacote antes de continuar.",
        variant: "destructive",
      });
      return;
    }

    bookingMutation.mutate({
      ...data,
      packageId: selectedPackage.id,
      totalPrice: totalPrice.toString(),
    });
  };

  return (
    <div className="bg-gradient-to-br from-primary/5 to-secondary/5 rounded-2xl p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <h3 className="font-poppins font-semibold text-xl sm:text-2xl text-text-primary mb-6 text-center">
          Resumo do Seu Pedido
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          <Card className="shadow-soft">
            <CardContent className="p-6">
              <h4 className="font-medium text-text-primary mb-4 flex items-center">
                <ClipboardList className="text-primary mr-2 h-5 w-5" />
                Detalhes do Pedido
              </h4>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-text-secondary">Pacote selecionado:</span>
                  <span className="font-medium text-text-primary">
                    {selectedPackage ? selectedPackage.name : 'Nenhum selecionado'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">Número de convidados:</span>
                  <span className="font-medium text-text-primary">{guestCount} pessoas</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-secondary">Preço por pessoa:</span>
                  <span className="font-medium text-primary">
                    R$ {selectedPackage ? selectedPackage.pricePerPerson.toFixed(2) : '0,00'}
                  </span>
                </div>
                <hr className="my-3" />
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-text-primary">Total:</span>
                  <span className="font-bold text-2xl text-primary">
                    R$ {totalPrice.toFixed(2)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-soft">
            <CardContent className="p-6">
              <h4 className="font-medium text-text-primary mb-4 flex items-center">
                <User className="text-primary mr-2 h-5 w-5" />
                Seus Dados
              </h4>
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="customerName" className="text-sm font-medium text-text-primary">
                    Nome completo
                  </Label>
                  <Input
                    id="customerName"
                    {...register("customerName")}
                    placeholder="Seu nome"
                    className="mt-2"
                  />
                  {errors.customerName && (
                    <p className="text-sm text-destructive mt-1">{errors.customerName.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="customerEmail" className="text-sm font-medium text-text-primary">
                    E-mail
                  </Label>
                  <Input
                    id="customerEmail"
                    type="email"
                    {...register("customerEmail")}
                    placeholder="seu@email.com"
                    className="mt-2"
                  />
                  {errors.customerEmail && (
                    <p className="text-sm text-destructive mt-1">{errors.customerEmail.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="customerPhone" className="text-sm font-medium text-text-primary">
                    Telefone
                  </Label>
                  <Input
                    id="customerPhone"
                    type="tel"
                    {...register("customerPhone")}
                    placeholder="(11) 99999-9999"
                    className="mt-2"
                  />
                  {errors.customerPhone && (
                    <p className="text-sm text-destructive mt-1">{errors.customerPhone.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="eventDate" className="text-sm font-medium text-text-primary">
                    Data do evento
                  </Label>
                  <Input
                    id="eventDate"
                    type="date"
                    {...register("eventDate")}
                    className="mt-2"
                  />
                  {errors.eventDate && (
                    <p className="text-sm text-destructive mt-1">{errors.eventDate.message}</p>
                  )}
                </div>
                
                <div className="pt-4">
                  <Button 
                    type="submit"
                    disabled={!selectedPackage || bookingMutation.isPending}
                    className="w-full bg-gradient-to-r from-success to-success/80 text-white font-bold py-4 text-lg hover:shadow-medium transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <CalendarCheck className="mr-2 h-5 w-5" />
                    {bookingMutation.isPending ? "Enviando..." : "Solicitar Orçamento"}
                  </Button>
                  <p className="text-sm text-text-light mt-3 text-center">
                    Após enviar, entraremos em contato em até 24 horas para confirmar os detalhes
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
