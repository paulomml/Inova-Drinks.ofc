import Header from "../components/Header";
import Hero from "../components/Hero";
import PackageCard from "../components/PackageCard";
import BookingSummary from "../components/BookingSummary";
import TrustSection from "../components/TrustSection";
import Footer from "../components/Footer";
import { useBooking } from "../hooks/useBooking";
import { useQuery } from "@tanstack/react-query";
import { Package } from "../../../shared/schema";

export interface DisplayPackage {
  id: string;
  name: string;
  type: string;
  description: string;
  drinks: unknown;
  cocktails: unknown;
  features: unknown;
  pricePerPerson: number;
  image: string;
  badge: string;
  badgeColor: string;
  buttonColor: string;
  isPopular: boolean;
}

const transformPackageForDisplay = (pkg: Package): DisplayPackage => {
  const getImageUrl = (type: string) => {
    switch (type) {
      case 'classico':
        return "https://images.unsplash.com/photo-1544145945-f90425340c7e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300";
      case 'vip':
        return "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300";
      case 'premium':
        return "https://images.unsplash.com/photo-1569529465841-dfecdab7503b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300";
      default:
        return "https://images.unsplash.com/photo-1544145945-f90425340c7e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300";
    }
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'classico':
        return "bg-secondary";
      case 'vip':
        return "bg-primary";
      case 'premium':
        return "bg-gradient-to-r from-yellow-400 to-yellow-600";
      default:
        return "bg-secondary";
    }
  };

  const getButtonColor = (type: string) => {
    switch (type) {
      case 'classico':
        return "bg-secondary hover:bg-secondary-dark";
      case 'vip':
        return "bg-gradient-to-r from-primary to-primary-light hover:shadow-medium";
      case 'premium':
        return "bg-gradient-to-r from-yellow-500 to-yellow-600 hover:shadow-medium";
      default:
        return "bg-secondary hover:bg-secondary-dark";
    }
  };

  return {
    ...pkg,
    pricePerPerson: parseFloat(pkg.pricePerPerson),
    image: getImageUrl(pkg.type),
    badge: pkg.name.replace('Pacote ', ''),
    badgeColor: getBadgeColor(pkg.type),
    buttonColor: getButtonColor(pkg.type),
    isPopular: pkg.isPopular === "true"
  };
};

export default function Home() {
  const {
    guestCount,
    selectedPackage,
    setGuestCount,
    setSelectedPackage,
    getTotalPrice,
    getSelectedPackageData
  } = useBooking();

  const { data: packages = [], isLoading } = useQuery<Package[]>({
    queryKey: ['/api/packages'],
  });

  const transformedPackages = packages.map(transformPackageForDisplay);

  const scrollToPackages = () => {
    document.getElementById('packages')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero 
        guestCount={guestCount}
        setGuestCount={setGuestCount}
        onScrollToPackages={scrollToPackages}
        totalPrice={getTotalPrice()}
      />
      
      <section id="packages" className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-poppins font-bold text-3xl lg:text-4xl text-text-primary mb-4">
              Escolha seu Pacote Ideal
            </h2>
            <p className="text-lg text-text-secondary max-w-3xl mx-auto">
              Nossos pacotes foram cuidadosamente elaborados para atender diferentes tipos de eventos. 
              Todos incluem open bar ilimitado, frutas frescas e atendimento especializado.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12">
            {isLoading ? (
              <div className="col-span-full text-center py-8">
                <p className="text-lg text-text-secondary">Carregando pacotes...</p>
              </div>
            ) : (
              transformedPackages.map((pkg) => (
                <PackageCard
                  key={pkg.id}
                  package={pkg}
                  isSelected={selectedPackage === pkg.id}
                  onSelect={setSelectedPackage}
                />
              ))
            )}
          </div>
          
          <BookingSummary 
            guestCount={guestCount}
            selectedPackage={getSelectedPackageData()}
            totalPrice={getTotalPrice()}
          />
        </div>
      </section>
      
      <TrustSection />
      <Footer />
    </div>
  );
}
