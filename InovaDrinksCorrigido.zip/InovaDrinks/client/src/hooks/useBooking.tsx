import { useState, useMemo } from "react";

const PACKAGES = {
  classico: { id: "classico", name: "Pacote Clássico", pricePerPerson: 35 },
  vip: { id: "vip", name: "Pacote VIP", pricePerPerson: 50 },
  premium: { id: "premium", name: "Pacote Premium", pricePerPerson: 75 }
};

export function useBooking() {
  const [guestCount, setGuestCount] = useState(50);
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);

  const getTotalPrice = useMemo(() => {
    return () => {
      if (!selectedPackage || !PACKAGES[selectedPackage as keyof typeof PACKAGES]) {
        return guestCount * 45; // Base price for estimation
      }
      return guestCount * PACKAGES[selectedPackage as keyof typeof PACKAGES].pricePerPerson;
    };
  }, [guestCount, selectedPackage]);

  const getSelectedPackageData = useMemo(() => {
    return () => {
      if (!selectedPackage || !PACKAGES[selectedPackage as keyof typeof PACKAGES]) {
        return null;
      }
      return PACKAGES[selectedPackage as keyof typeof PACKAGES];
    };
  }, [selectedPackage]);

  return {
    guestCount,
    selectedPackage,
    setGuestCount,
    setSelectedPackage,
    getTotalPrice,
    getSelectedPackageData
  };
}
